const CONFIG = {

    API_BASE: window.location.origin,

    ENDPOINTS: {

        LOGIN: "/auth/login",
        REGISTER: "/auth/register",
        GOOGLE: "/auth/google",

        FILES: "/api/files",
        FOLDERS: "/api/folders",

        UPLOAD: "/api/files/upload",

        DOWNLOAD: "/api/files/download",

        DELETE: "/api/files",

        MOVE: "/api/files/move",

        COPY: "/api/files/copy",

        RENAME: "/api/files/rename",

        SHARE: "/api/share",

        PROFILE: "/api/users/profile"

    }

};

function getToken() {
    return localStorage.getItem("jwtToken");
}

function authHeaders() {

    const headers = {
        "Content-Type": "application/json"
    };

    const token = getToken();

    if (token) {
        headers["Authorization"] = "Bearer " + token;
    }

    return headers;
}

function authFetch(url, options = {}) {

    options.headers = {
        ...authHeaders(),
        ...(options.headers || {})
    };

    return fetch(CONFIG.API_BASE + url, options)
        .then(async response => {

            if (response.status === 401) {

                localStorage.removeItem("jwtToken");

                window.location.href = "/login.html";

                return;
            }

            return response;
        });

}
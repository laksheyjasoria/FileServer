class Api {

    static async request(url, method = "GET", body = null, isFormData = false) {

        const token = localStorage.getItem("jwtToken");

        const headers = {};

        if (!isFormData) {
            headers["Content-Type"] = "application/json";
        }

        if (token) {
            headers["Authorization"] = "Bearer " + token;
        }

        const options = {
            method,
            headers
        };

        if (body) {
            options.body = isFormData ? body : JSON.stringify(body);
        }

        const response = await fetch(CONFIG.API_BASE + url, options);

        if (response.status === 401) {

            localStorage.clear();

            window.location.href = "/login.html";

            return;
        }

        if (!response.ok) {

            let message = "Request Failed";

            try {
                const err = await response.json();
                message = err.message || message;
            } catch (e) { }

            throw new Error(message);
        }

        const type = response.headers.get("content-type");

        if (type && type.includes("application/json")) {
            return response.json();
        }

        return response;
    }

    // ===========================
    // FILE LIST
    // ===========================

    static getFiles(parentId = null) {

        let url = CONFIG.ENDPOINTS.FILES;

        if (parentId) {
            url += "?parentId=" + parentId;
        }

        return this.request(url);

    }

    // ===========================
    // SEARCH
    // ===========================

    static search(keyword) {

        return this.request(
            CONFIG.ENDPOINTS.FILES + "/search?query=" +
            encodeURIComponent(keyword)
        );

    }

    // ===========================
    // CREATE FOLDER
    // ===========================

    static createFolder(data) {

        return this.request(

            CONFIG.ENDPOINTS.FOLDERS,

            "POST",

            data

        );

    }

    // ===========================
    // UPLOAD
    // ===========================

    static upload(file, parentId) {

        const form = new FormData();

        form.append("file", file);

        if (parentId) {
            form.append("parentId", parentId);
        }

        return this.request(

            CONFIG.ENDPOINTS.UPLOAD,

            "POST",

            form,

            true

        );

    }

    // ===========================
    // DELETE
    // ===========================

    static delete(ids) {

        return this.request(

            CONFIG.ENDPOINTS.DELETE,

            "DELETE",

            {
                ids: ids
            }

        );

    }

    // ===========================
    // MOVE
    // ===========================

    static move(ids, destinationId) {

        return this.request(

            CONFIG.ENDPOINTS.MOVE,

            "PUT",

            {

                ids,

                destinationId

            }

        );

    }

    // ===========================
    // COPY
    // ===========================

    static copy(ids, destinationId) {

        return this.request(

            CONFIG.ENDPOINTS.COPY,

            "POST",

            {

                ids,

                destinationId

            }

        );

    }

    // ===========================
    // RENAME
    // ===========================

    static rename(id, newName) {

        return this.request(

            CONFIG.ENDPOINTS.RENAME,

            "PUT",

            {

                id,

                newName

            }

        );

    }

    // ===========================
    // DOWNLOAD
    // ===========================

    static download(id) {

        window.open(

            CONFIG.API_BASE +
            CONFIG.ENDPOINTS.DOWNLOAD +
            "/" +
            id,

            "_blank"

        );

    }

    // ===========================
    // SHARE
    // ===========================

    static share(data) {

        return this.request(

            CONFIG.ENDPOINTS.SHARE,

            "POST",

            data

        );

    }

    // ===========================
    // PROFILE
    // ===========================

    static profile() {

        return this.request(

            CONFIG.ENDPOINTS.PROFILE

        );

    }

}
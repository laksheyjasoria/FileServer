package com.app.resource.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.app.drive.service.CopyService;
import com.app.drive.service.CreateFolderService;
import com.app.drive.service.DeleteService;
import com.app.drive.service.MoveService;
import com.app.drive.service.RenameService;
import com.app.resource.dto.ResourceActionRequest;
import com.app.resource.enumtype.ResourceAction;

@Service
public class ResourceService {

    private final DeleteService deleteService;
    private final CopyService copyService;
    private final MoveService moveService;
    private final RenameService renameService;
    private final CreateFolderService createFolderService;

    public ResourceService(DeleteService deleteService,
            CopyService copyService,
            MoveService moveService,
            RenameService renameService,
            CreateFolderService createFolderService) {
        this.deleteService = deleteService;
        this.copyService = copyService;
        this.moveService = moveService;
        this.renameService = renameService;
        this.createFolderService = createFolderService;
    }

    public void handle(ResourceActionRequest request, String userId) {

        List<String> ids = request.getIds();

        if (request.getAction() == ResourceAction.DELETE) {
            ids.forEach(deleteService::delete);
            return;
        }

        if (request.getAction() == ResourceAction.COPY) {
            ids.forEach(copyService::copy);
            return;
        }

        if (request.getAction() == ResourceAction.MOVE) {
            // destination contains destination folder id
            String dest = request.getDestination();
            ids.forEach(id -> moveService.move(id, dest));
            return;
        }

        if (request.getAction() == ResourceAction.RENAME) {
            // name contains new name
            String newName = request.getName();
            ids.forEach(id -> renameService.rename(id, newName));
            return;
        }

        if (request.getAction() == ResourceAction.CREATE_FOLDER) {
            // name contains folder name, destination contains parentId (optional)
            String name = request.getName();
            String parent = request.getDestination();
            createFolderService.create(userId, name, parent);
            return;
        }
    }

}
package com.app.storage.service;

import org.springframework.web.multipart.MultipartFile;

public interface StorageService {

    String upload(MultipartFile file);

    byte[] download(String fileId);
}
package com.app.storage.service;

import java.io.IOException;
import java.util.Map;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.app.config.TelegramStorageProperties;
import com.app.core.exception.StorageException;

@Service
public class TelegramStorageService implements StorageService {

	private final TelegramStorageProperties props;
	private final RestTemplate restTemplate = new RestTemplate();

	public TelegramStorageService(TelegramStorageProperties props) {
		this.props = props;
	}

	// ================= UPLOAD =================
	@Override
	public String upload(MultipartFile file) {

		try {

			String url = "https://api.telegram.org/bot" + props.getBotToken() + "/sendDocument";

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.MULTIPART_FORM_DATA);

			var body = new org.springframework.util.LinkedMultiValueMap<String, Object>();

			body.add("chat_id", props.getChatId());
			body.add("document", new org.springframework.core.io.ByteArrayResource(file.getBytes()) {
				@Override
				public String getFilename() {
					return file.getOriginalFilename();
				}
			});

			HttpEntity<?> request = new HttpEntity<>(body, headers);

			ResponseEntity<Map> response = restTemplate.postForEntity(url, request, Map.class);

			// 🔥 Extract file_id
			Map result = (Map) response.getBody().get("result");
			Map document = (Map) result.get("document");

			return (String) document.get("file_id");

		} catch (IOException e) {
			throw new StorageException("Telegram upload failed");
		}
	}

	// ================= DOWNLOAD =================
	@Override
	public byte[] download(String fileId) {

		try {

			// Step 1: get file path
			String getFileUrl = "https://api.telegram.org/bot" + props.getBotToken() + "/getFile?file_id=" + fileId;

			Map response = restTemplate.getForObject(getFileUrl, Map.class);

			Map result = (Map) response.get("result");
			String filePath = (String) result.get("file_path");

			// Step 2: download file
			String fileUrl = "https://api.telegram.org/file/bot" + props.getBotToken() + "/" + filePath;

			return restTemplate.getForObject(fileUrl, byte[].class);

		} catch (Exception e) {
			throw new StorageException("Telegram download failed");
		}
	}
}
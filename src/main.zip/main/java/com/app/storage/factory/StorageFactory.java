package com.app.storage.factory;

import org.springframework.stereotype.Component;

import com.app.storage.service.StorageService;

@Component
public class StorageFactory {

	private final StorageService telegram;

	public StorageFactory(StorageService telegram) {
		this.telegram = telegram;
	}

	public StorageService get() {
		return telegram; // later switch via config
	}
}